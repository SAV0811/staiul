import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from linear_regression import LinearRegression
from normal_equation import NormalEquation

# import file csv and put it into a dataframe
houses = pd.read_csv('datasets/houses_portaland_simple.csv')

# the dataframe's describe method returns a table with some insights on the dataframe
print(houses.describe())

# the drop method allows to remove specified row or column
# inplace=True modifies the actual dataframe, without creating a new one by copying the original into the newest
houses.drop(columns='Bedroom', inplace=True)

# the sample method allows to randomly pick some samples from the dataframe:
# with frac=1 we ask to select the 100% of the samples, but they will be shuffled randomly
houses = houses.sample(frac=1, random_state=15)

# after shuffling the dataset, the indexes will be shuffled as well; using reset_index allows to reset the indexes
# the drop parameter allows to drop the previous indexes' column and to create a new one
houses = houses.reset_index(drop=True)

# the plot function is used do draw points in a diagram
# the first argument specifies the points on the x-axis, the second the points on the y-axis
# by default, plot plots lines between the points specified as arguments
# specifying a third argument we can plot dots or circles or whatever
# with ro we are prompting to draw red o's (little circles)
plt.plot(houses.Size, houses.Price, 'ro')
plt.show()

# conversely, we can analyse the correlations in the dataset without plotting it
# the corr() method finds the correlation of each column
# the method takes two parameters: method (that can be kendall, pearson (by default), spearman, or a callable function)
# min_periods that indicates the minimum number of observations required to return a good enough result
# Pearson's coefficient: https://en.wikipedia.org/wiki/Pearson_correlation_coefficient
print(houses.corr())

# returns all the values in the dataframe in a 2-dimensional array with one array for each row
# 2 columns: one per feature
houses = houses.values

# FEATURE SCALING (Z-SCORE NORMALIZATION)
# calculates the mean and std dev value for each feature in the dataset
# two values will be calculated: the mean and std dev of the feature Size and the mean and std dev of the feature Price
mean = houses.mean(axis=0)
std = houses.std(axis=0)

# formula for z-score normalization (x' = (x - mu) / sigma)
houses = (houses - mean) / std
print(houses)

# take the feature value Size as the input value
X = houses[:, 0]

# take the feature value Price as the output value
y = houses[:, 1]

plt.plot(X, y, 'b.')
plt.show()

# let's add the bias term: it will be a column of 1's that will be appended to the X vector
# the "index routine" numpy.c_ concatenates the second object to the first one
# we are creating a vector of 1's using the ones() method indicating as dimension the shape of X and
# then append X to this ones vector
# notice that shape returns a vector indicating the length of the dimensions of the array (47, ) in this particular case
# moreover, notice that now X will be a 2-dimensional matrix, with a column of ones
# and the second column will indicate the houses' sizes
X = np.c_[np.ones(X.shape[0]), X]

# let's create the regression
linear = LinearRegression(n_features=X.shape[1], n_steps=10000, learning_rate=0.001)

# plotting the first result of the Linear Regression
lineX = np.linspace(X[:, 1].min(), X[:, 1].max(), 100)
liney = [linear.theta[0] + linear.theta[1] * xx for xx in lineX]
plt.plot(X[:, 1], y, 'r.', label='Training data')
plt.plot(lineX, liney, 'b--', label='Current hypothesis')
plt.legend()
plt.show()

# let's train the model
cost_history, theta_history = linear.fit(X, y)

# print the final values of theta
print(f'''Thetas: {*linear.theta,}''')

# print the final value of the cost function
print(f'''Final train cost:  {cost_history[-1]:.3f}''')

ne = NormalEquation(X, y)
theta_ne = ne.fit()

print(f'''Thetas NE: {theta_ne}''')

# plot the final result for this regressor
lineX = np.linspace(X[:, 1].min(), X[:, 1].max(), 100)
liney = [theta_history[-1, 0] + theta_history[-1, 1] * xx for xx in lineX]
plt.plot(X[:, 1], y, 'r.', label='Training data')
plt.plot(lineX, liney, 'b--', label='Current hypothesis')
plt.legend()
plt.show()

# plot the cost history for this regression problem
plt.plot(cost_history, 'g--', label='Cost Function')
plt.legend()
plt.show()

# -- OPTIONAL -- CONTOUR PLOT --

# Grid over which we will calculate J
theta0_vals = np.linspace(-2, 2, 100)
theta1_vals = np.linspace(-2, 3, 100)

J_vals = np.zeros((theta0_vals.size, theta1_vals.size))

# Fill out J_vals
for t1, element in enumerate(theta0_vals):
    for t2, element2 in enumerate(theta1_vals):
        thetaT = np.zeros(shape=(2, 1))
        thetaT[0][0] = element
        thetaT[1][0] = element2
        h = X.dot(thetaT.flatten())
        j = (h - y)
        J = j.dot(j) / 2 / (len(X))
        J_vals[t1, t2] = J

# Contour plot
J_vals = J_vals.T

A, B = np.meshgrid(theta0_vals, theta1_vals)
C = J_vals

cp = plt.contourf(A, B, C)
plt.colorbar(cp)
plt.plot(theta_history.T[0], theta_history.T[1], 'r--')
plt.show()
