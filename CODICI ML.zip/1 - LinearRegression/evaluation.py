import numpy as np


class Evaluation:

    def __init__(self, model):
        self._model = model

    def compute_performance(self, X, y):
        preds = self._model.predict(X)

        mae = self._mean_absolute_error(preds, y)
        mape = self._mean_absolute_percentage_error(preds, y)
        mpe = self._mean_percentage_error(preds, y)
        mse = self._mean_squared_error(preds, y)
        rmse = self._root_mean_squared_error(preds, y)
        r2 = self._r_2(preds, y)

        return {'mae': mae, 'mape': mape, 'mpe': mpe, 'mse': mse, 'rmse': rmse, 'r2': r2}

    def _mean_absolute_error(self, preds, y):
        return np.mean(np.abs(preds - y))

    def _mean_absolute_percentage_error(self, preds, y):
        return np.mean(np.abs(preds - y) / y)

    def _mean_percentage_error(self, preds, y):
        return np.mean((preds - y) / y)

    def _mean_squared_error(self, preds, y):
        return np.mean((preds - y) ** 2)

    def _root_mean_squared_error(self, preds, y):
        return np.sqrt(self._mean_squared_error(preds, y))

    def _r_2(self, preds, y):
        sst = np.sum((y - y.mean()) ** 2)
        ssr = np.sum((preds - y) ** 2)

        return 1 - (ssr / sst)
