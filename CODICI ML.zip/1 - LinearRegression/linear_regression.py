import numpy as np

# setting the random seed to a specific value
# ensures that the random number generation will produce the same sequence each time the code is run
# the random generation is used to initialize the weights
np.random.seed(123)


class LinearRegression:
    # the __init__ class is the constructor
    # we define three parameters: the learning rate (0.01 by default),
    # the number of steps (for the GD algorithm) - 2000 by default -,
    # and the number of features (1 by default)
    def __init__(self, learning_rate=1e-2, n_steps=2000, n_features=1):
        self.learning_rate = learning_rate
        self.n_steps = n_steps
        self.n_features = n_features
        # let's initialize randomly the parameters
        self.theta = np.random.rand(n_features)

    # the fit function will apply the GD in full batch mode without regularization
    # it will return the cost and theta histories
    def fit(self, X, y):
        # m represents the number of samples
        m = len(X)

        # initialize with zeros the cost_history vector
        cost_history = np.zeros(self.n_steps)

        # initialize with zero the theta_history matrix
        theta_history = np.zeros((self.n_steps, self.theta.shape[0]))

        for step in range(0, self.n_steps):
            # remember that in linear regression the hypothesis function is the dot product
            # between the feature vector and the weight vector
            preds = self.predict(X)

            # now let's calculate the error as the difference between predictions and actual output
            error = preds - y

            # G represents the derivative of the cost function w.r.t. the theta parameters
            G = (1 / m) * np.dot(X.T, error)

            # the update rule is as follows
            self.theta -= self.learning_rate * G
            theta_history[step, :] = self.theta.T
            cost_history[step] = (1 / (2 * m)) * np.dot(error.T, error)

        return cost_history, theta_history

    def fit_mini_batch(self, X, y, b=50):
        m = len(X)
        cost_history = np.zeros(self.n_steps)
        theta_history = np.zeros((self.n_steps, self.theta.shape[0]))

        for step in range(0, self.n_steps):
            total_error = np.zeros(X.shape[1])
            for i in range(0, m, b):
                x_i = X[i:i+b]
                y_i = y[i:i+b]

                preds = self.predict(x_i)
                error = preds - y_i

                total_error += np.dot(x_i.T, error)

            self.theta -= self.learning_rate * total_error / b
            theta_history[step, :] = self.theta.T

            preds = self.predict(X)
            error = preds - y
            cost_history[step] = (1 / 2 * m) * np.dot(error.T, error)

        return cost_history, theta_history

    def fit_sgd(self, X, y):
        m = len(X)
        cost_history = np.zeros(self.n_steps)
        theta_history = np.zeros((self.n_steps, self.theta.shape[0]))

        for step in range(0, self.n_steps):
            random_index = np.random.randint(m)
            x_i = X[random_index]
            y_i = y[random_index]
            preds = self.predict(x_i)
            error = preds - y_i
            self.theta -= self.learning_rate * np.dot(x_i.T, error)

            theta_history[step, :] = self.theta.T
            preds = self.predict(X)
            error = preds - y
            cost_history[step] = (1 / 2 * m) * np.dot(error.T, error)

        return cost_history, theta_history

    def predict(self, X):
        return np.dot(X, self.theta)
