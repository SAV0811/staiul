import numpy as np
import pandas as pd
import operator
import matplotlib.pyplot as plt
from evaluation import Evaluation
from linear_regression import LinearRegression

# import the dataset in a pandas' dataframe
houses = pd.read_csv('datasets/houses.csv')

# shuffle the dataset to remove grouping bias
houses = houses.sample(frac=1).reset_index(drop=True)

# pick only few features
X = houses[['GrLivArea', 'LotArea']].values

# set the ground truth
y = houses['SalePrice'].values

# create and add the polynomial terms
X_squared = X ** 2
X_cubic = X ** 3
X_fourth = X ** 4
X = np.column_stack((X, ))

# find the index to split the dataset into train and test sets
train_index = round(len(X) * 0.8)

# split the dataset into train and test sets
# train set
X_train = X[:train_index]
y_train = y[:train_index]

# test set
X_test = X[train_index:]
y_test = y[train_index:]

# find mean and std deviation to normalize the data
mean = X_train.mean(axis=0)
std = X_train.std(axis=0)

# normalize the dataset using Z - score normalization
X_train = (X_train - mean) / std
X_test = (X_test - mean) / std

# add the bias term
X_train = np.c_[np.ones(X_train.shape[0]), X_train]
X_test = np.c_[np.ones(X_test.shape[0]), X_test]

# create the regressor
linear = LinearRegression(learning_rate=0.05, n_features=X_train.shape[1], n_steps=1000)

# fit the model
cost_history, theta_history = linear.fit(X_train, y_train)

# print the final values
print(f'''Thetas: {*linear.theta, }''')
print(f'''Final train cost: {cost_history[-1]:.3f}''')

# create the prediction array
preds = linear.predict(X_test)

# plot the values
sort_axis = operator.itemgetter(0)
sorted_zip = sorted(zip(X_test[:, 1], preds), key=sort_axis)
x_poly, y_poly_pred = zip(*sorted_zip)

plt.plot(X_test[:, -1], y_test, 'r.', label='Training data')
plt.plot(x_poly, y_poly_pred, 'b--', label='Current hypothesis')
plt.legend()
plt.show()
plt.show()

eval = Evaluation(linear)
print(eval.compute_performance(X_test, y_test))