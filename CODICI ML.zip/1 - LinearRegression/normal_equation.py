import numpy as np


class NormalEquation:
    def __init__(self, X, y):
        self.X = X
        self.y = y

    def fit(self):
        XXT_1 = np.linalg.inv(np.dot(self.X.T, self.X))
        XX = np.dot(XXT_1, self.X.T)
        theta = np.dot(XX, self.y)

        return theta