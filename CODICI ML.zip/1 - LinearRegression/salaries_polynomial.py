import operator
import pandas as pd
import numpy as np
from linear_regression import LinearRegression
from matplotlib import pyplot as plt

salaries = pd.read_csv('datasets/Position_Salaries_base.csv')
plt.plot(salaries.Level, salaries.Salary, 'ro')
plt.show()

# cast the dataframe into a multi-dimensional array
salaries = salaries.values

# compute mean and standard deviation
mean = salaries.mean(axis=0)
std = salaries.std(axis=0)

# compute Z - score normalization:
salaries = (salaries - mean) / std

# create feature vector and ground truth vector
X = salaries[:, 0]
y = salaries[:, 1]

# create new features powering to 2nd and 3rd power the original feature vector
X_squared = X ** 2
X_cubic = X ** 3

# column_stack is a method used to combine the arrays into a matrix:
X = np.column_stack((X, X_squared, X_cubic))

# add the bias term
X = np.c_[np.ones(X.shape[0]), X]

# create the regressor
linear = LinearRegression(n_features=X.shape[1], learning_rate=0.01, n_steps=100000)

# train the model
cost_history, theta_history = linear.fit(X, y)

print(f'''Thetas: {*linear.theta, }''')
print(f'''Cost history: {cost_history[-1]:.3f}''')

# obtain the predictions
preds = linear.predict(X)

# plot the results
sort_axis = operator.itemgetter(0)
sorted_zip = sorted(zip(X[:, 1], preds), key=sort_axis)
x_poly, y_poly_pred = zip(*sorted_zip)
plt.plot(X[:, 1], y, 'r.', label='Training data')
plt.plot(x_poly, preds, 'b--', label='Current hypothesis')
plt.legend()
plt.show()
plt.show()