import pandas as pd
import numpy as np
# import matplotlib.pyplot as plt
from linear_regression import LinearRegression
# from utilities import plot_theta_gd
from evaluation import Evaluation

pd.set_option('display.max_columns', None)

# import the dataset and create a pandas dataframe:
houses = pd.read_csv('datasets/houses.csv')

# shuffle the dataset to remove group bias
houses = houses.sample(frac=1).reset_index(drop=True)

# select few features as inputs to the model; X will be a 4-dimensional array
X = houses[['GrLivArea', 'LotArea', 'GarageArea', 'FullBath']].values
print(X)
"""
# select the target value, which is the ground truth
y = houses['SalePrice'].values

# to split the dataset into training and testing sets, we need to calculate the index that will split the dataset
train_index = round(len(houses) * 0.8)

# now create four arrays from the entire dataset such that we can obtain the train set and test set
# train set
X_train = X[:train_index]
y_train = y[:train_index]
# test set
X_test = X[train_index:]
y_test = y[train_index:]

# compute mean and standard deviation on the training set
mean = X_train.mean(axis=0)
std = X_train.std(axis=0)

# normalizing the dataset using Z - score normalization:
X_train = (X_train - mean) / std
X_test = (X_test - mean) / std

# add bias column
X_train = np.c_[np.ones(X_train.shape[0]), X_train]
X_test = np.c_[np.ones(X_test.shape[0]), X_test]

# create the regressor
linear = LinearRegression(learning_rate=0.05, n_steps=1000, n_features=X_train.shape[1])

# fit the regressor
cost_history, theta_history = linear.fit(X_train, y_train)

print(f'''Thetas: {*linear.theta, }''')
print(f'''Final train cost: {cost_history[-1]:.3f}''')

plt.plot(cost_history, 'g--')
plt.show()

staiul = Evaluation(linear)

print(staiul.compute_performance(X_test, y_test))

plot_theta_gd(X_train, y_train, linear, cost_history, theta_history, 0, 3)"""