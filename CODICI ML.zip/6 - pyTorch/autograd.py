import math

import torch
from matplotlib import pyplot as plt

# the linspace() method generates 25 (steps=25) values equally spaced between 0 and 2*pi
# the requires_grad parameter set to True tells to track all the operations performed on the tensor
# this is useful when training the NN with the backpropagation method
a = torch.linspace(0., 2. * math.pi, steps=25, requires_grad=True)
print(a)

# the sin() method applied on the tensor a generates a new tensor where all the values are the sines of the values of a
b = torch.sin(a)
print(b)

# to plot the relation between a and b we can use matplotlib.pyplot
# first thing first, we should stop the tracking of the operations on the tensors
# since this is useless for the gradient computations
with torch.no_grad():
    plt.plot(a, b)
    plt.xlabel('a (radians)')
    plt.ylabel('sin(a)')
    plt.title('Sine Function')
    plt.grid(True)
    plt.show()

# let's do other computations
# create a tensor c which contains the values of b multiplied by 2
c = 2 * b
print(c)
# create a tensor d which contains the values of c added by 1
d = c + 1
print(d)
# create a tensor out which contains a single value that is the sum of all the values of d
out = d.sum()
print(out)
# when a tensor is created as a result of an operation, it has grad_fn
# grad_fn contains the operation used to generate the tensor
print('out:')
print(out.grad_fn)
print(out.grad_fn.next_functions)
print(out.grad_fn.next_functions[0][0].next_functions)
print(out.grad_fn.next_functions[0][0].next_functions[0][0].next_functions)
print(out.grad_fn.next_functions[0][0].next_functions[0][0].next_functions[0][0].next_functions)
print(out.grad_fn.next_functions[0][0].next_functions[0][0].next_functions[0][0].next_functions[0][0].next_functions)

print('\na:')
print(a.grad_fn)

# the first tensor has no grad_fn because only leaf nodes have gradients computed
# to perform the derivatives, it will be sufficient to call the backward() method on the last tensor
out.backward()
print(a.grad)

# we can plot the derivative as
plt.plot(a.detach(), a.grad.detach())
plt.show()