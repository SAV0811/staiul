import pandas as pd
import torch
from matplotlib import pyplot as plt
from sklearn.datasets import make_circles
from sklearn.model_selection import train_test_split
from torch import optim, nn

from circle_model import CircleModel

n_samples = 1000
# the make_circles() function of sklearn allows to test non-linear classification algorithm since it generates
# two concentric circles
X, y = make_circles(n_samples=n_samples, noise=0.03, random_state=42)

# create a pandas' dataframe structure using the previously generated data
circles = pd.DataFrame({"X1": X[:, 0],
                        "X2": X[:, 1],
                        "label": y
                        })

plt.scatter(x=X[:, 0], y=X[:, 1], c=y, cmap='RdYlBu')
plt.show()

# split the dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# set up device
device = 'cuda' if torch.cuda.is_available() else 'cpu'
print(device)

# convert the sets into tensors
X_train = torch.from_numpy(X_train).float().to(device)
X_test = torch.from_numpy(X_test).float().to(device)
y_train = torch.from_numpy(y_train).float().to(device)
y_test = torch.from_numpy(y_test).float().to(device)

# set up the seed
torch.manual_seed(42)

# set up the input layer size
input_size = X.shape[1]

# set up the hidden layer size
hidden_size = 50

# set up the output layer size
output_size = 1

# instantiate the model
circle_model = CircleModel(input_size, hidden_size, output_size).to(device)

# calculate the loss
criterion = nn.BCELoss()

# set the optimizer
optimizer = optim.SGD(circle_model.parameters(), lr=0.01)

# set the number of epochs
epochs = 3000
for epoch in range(epochs):
    # instantiate the training
    circle_model.train()

    # Forward pass
    outputs = circle_model(X_train).squeeze()
    loss = criterion(outputs, y_train)

    # Calculate accuracy
    acc = circle_model.accuracy_fn(y_true=y_train, y_pred=torch.round(outputs))

    # Backward pass and optimization
    loss.backward()
    optimizer.step()
    optimizer.zero_grad()

    # Evaluation on the test set
    circle_model.eval()
    with torch.inference_mode():
        test_outputs = circle_model(X_test).squeeze()
        test_loss = criterion(test_outputs, y_test)
        test_acc = circle_model.accuracy_fn(y_true=y_test, y_pred=torch.round(test_outputs))

    if (epoch + 1) % 20 == 0:
        print(f"Epoch: {epoch + 1} | Loss: {loss:.5f}, Accuracy: {acc:.2f}% | "
              f"Test loss: {test_loss:.5f}, Test acc: {test_acc:.2f}%")
