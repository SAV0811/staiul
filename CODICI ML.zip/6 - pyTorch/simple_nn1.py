import torch
from torch import nn


class SimpleNN_1(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        # recall the constructor of the superclass (nn.Module)
        super(SimpleNN_1, self).__init__()
        # create the first fully connected layer as an object of the Linear class of nn
        # it'll be the layer between the input layer and the hidden layer
        self.fc1 = nn.Linear(input_size, hidden_size)
        # similarly, create the second fully connected layer between the hidden layer and the output one
        self.fc2 = nn.Linear(hidden_size, output_size)
        # define the sigmoid as the activation function as an object of the class Sigmoid of nn
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        x = self.fc1(x)
        x = self.sigmoid(x)
        x = self.fc2(x)
        x = self.sigmoid(x)
        return x

    def accuracy_fn(self, y_true, y_pred):
        correct = torch.eq(y_true, y_pred).sum().item()
        acc = (correct / len(y_pred)) * 100
        return acc