import numpy as np
import torch

# create a tensor from a list
data = [[1, 2], [3, 4]]
x_data = torch.tensor(data)
print(f'First Tensor:\n {x_data}')

# create a tensor from a Numpy array
np_array = np.array(data)
x_np = torch.from_numpy(np_array)
print(f'From Numpy:\n {x_np}')

shape = (2, 3)

# create a tensor with random values
rand_tensor = torch.rand(shape)
print(f'Random Tensor:\n {rand_tensor}')

# create a tensor full of ones
ones_tensor = torch.ones(shape)
print(f'Ones Tensor:\n {ones_tensor}')

# create a tensor full of zeros
zeros_tensor = torch.zeros(shape)
print(f'Zeros Tensor:\n {zeros_tensor}')


tensor = torch.rand(shape)
print(f'Tensor:\n {tensor}')
# print the shape of a tensor
print(f'Tensor\'s Shape:\n {tensor.shape}')

# print the data type of the tensor's values
print(f'Tensor\'s Data Type:\n {tensor.dtype}')

# print the device on which the tensor is stored
print(f'Tensor\'s Device:\n {tensor.device}')

# change the device from CPU to GPU using CUDA (Compute Unified Device Architecture)
if torch.cuda.is_available():
    tensor = tensor.to('cuda')

print(f'New Device:\n {tensor.device}')

# let's do some operations on tensors

# standard indexing and slicing
print(f'First Row: {tensor[0]}')
print(f'First Column: {tensor[:, 0]}')
print(f'Last Column: {tensor[:, -1]}')

# set the second column to 0
tensor[:, 1] = 0
print(tensor)

# join multiple tensors
# with dim=0 we are telling to join the tensors over the dimension 0, which is the "x" value (shape=(x,y,z,...))
t1 = torch.cat([tensor, tensor, tensor], dim=0)
print(t1)

# arithmetic operations
# matrix multiplication with @ operator
y1 = tensor @ tensor.T
print(y1)

# matrix multiplication using matmul()
y2 = tensor.matmul(tensor.T)
print(y2)

# matrices' element wise multiplication with * operator
z1 = tensor * tensor
print(z1)

# matrices' element wise multiplication using mul()
z2 = tensor.mul(tensor)
print(z2)

# sum all the elements of the tensor as a tensor itself
agg = tensor.sum()
print(agg)

# returns the actual numerical value of the tensor's value
agg_item = agg.item()
print(agg_item)