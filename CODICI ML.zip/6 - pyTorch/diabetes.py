import pandas as pd
import torch
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from torch import nn, optim

from simple_nn1 import SimpleNN_1
from simple_nn2 import SimpleNN_2

diabetes = pd.read_csv('datasets/diabetes.csv')

X = diabetes.drop(columns='Outcome').values
y = diabetes.Outcome.values

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

device = 'cuda' if torch.cuda.is_available() else 'cpu'

torch.manual_seed(42)
# setting non_linearity to True implies the use of the SimpleNN_1 which is non-linear
# the accuracy of the first NN is around 64 %: that means that the NN is underfitting
# when setting non_linearity to False it implies to use SimpleNN_2 which is linear
# the accuracy of the second NN is around 74 %, that is quite good performance
non_linearity = True
input_size = X.shape[1]
hidden_size = 50
output_size = 1

if non_linearity:
    model = SimpleNN_1(input_size, hidden_size, output_size).to(device)
else:
    model = SimpleNN_2(input_size, hidden_size, output_size).to(device)

# define the loss function (Binary Cross Entropy Loss)
criterion = nn.BCELoss()

# set the algorithm to compute the GD (we use the optim library of pytorch and use the SGD method)
optimizer = optim.SGD(model.parameters(), lr=0.001)

# convert the numpy arrays into pytorch's tensors, convert the values of the tensors into float values
# and set the computation device
X_train = torch.from_numpy(X_train).float().to(device)
X_test = torch.from_numpy(X_test).float().to(device)
y_train = torch.from_numpy(y_train).float().to(device)
y_test = torch.from_numpy(y_test).float().to(device)

# set the epochs and train the model
epochs = 3000
for epoch in range(epochs):
    # instantiate the training
    model.train()
    # make predictions on the training set and squeeze them to remove useless dimensions
    outputs = model(X_train).squeeze()
    # compute the loss function
    loss = criterion(outputs, y_train)
    # the round function of torch rounds each element to the nearest integer between 0 and 1
    outputs = torch.round(outputs).float()
    # compute the accuracy of the model
    acc = model.accuracy_fn(y_true=y_train, y_pred=outputs)
    # using the backward() method we are computing the derivatives of the loss function
    # w.r.t. all the parameters of the model
    # this must be done before updating the parameters
    loss.backward()
    # update the parameters
    optimizer.step()
    # resetting the gradients before the new cycle
    optimizer.zero_grad()
    # instantiate the evaluation
    model.eval()
    # now we want to predict labels of unseen data, thus there is no need to compute gradients anymore
    with torch.no_grad():
        test_outputs = torch.round(model(X_test).squeeze()).float()
        test_loss = criterion(test_outputs, y_test)
        test_acc = model.accuracy_fn(y_true=y_test, y_pred=test_outputs)

    if (epoch + 1) % 20 == 0:
        print(
            f"Epoch: {epoch} | Loss: {loss:.5f}, Accuracy: {acc:.2f}% | Test loss: {test_loss:.5f},"
            f" Test acc: {test_acc:.2f}%")
