import numpy as np


class RegressionMetrics:
    def __init__(self, y, preds):
        self.y = y
        self.preds = preds

    def compute_performance(self):
        mae = self._mean_absolute_error()
        mape = self._mean_absolute_percentage_error()
        mpe = self._mean_percentage_error()
        mse = self._mean_squared_error()
        rmse = self._root_mean_squared_error()
        r2 = self._r_2()

        return {'mae': mae, 'mape': mape, 'mpe': mpe, 'mse': mse, 'rmse': rmse, 'r2': r2}

    def _mean_absolute_error(self):
        return np.mean(np.abs(self.preds - self.y))

    def _mean_absolute_percentage_error(self):
        return np.mean(np.abs(self.preds - self.y) / self.y)

    def _mean_percentage_error(self):
        return np.mean((self.preds - self.y) / self.y)

    def _mean_squared_error(self):
        return np.mean((self.preds - self.y) ** 2)

    def _root_mean_squared_error(self):
        return np.sqrt(self._mean_squared_error())

    def _r_2(self):
        sst = np.sum((self.y - self.y.mean()) ** 2)
        ssr = np.sum((self.preds - self.y) ** 2)

        return 1 - (ssr / sst)
