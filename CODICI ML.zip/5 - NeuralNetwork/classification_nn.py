import numpy as np
from matplotlib import pyplot as plt

from classification_metrics import ClassificationMetrics


def sigmoid(z):
    return 1 / (1 + np.exp(-z))

def sigmoid_derivative(z):
    return sigmoid(z) * (1 - sigmoid(z))


class NeuralNetwork:
    def __init__(self, layers, epochs=700, alpha=1e-2, lmd=0.1):
        self.layers = layers
        self.n_layers = len(layers)
        self.epochs = epochs
        self.alpha = alpha
        self.lmd = lmd

        self.b = {}
        self.w = {}
        self.loss = []
        self.loss_val = []

    def init_parameters(self):
        np.random.seed(42)
        for i in range(1, self.n_layers):
            self.w[i] = np.random.randn(self.layers[i], self.layers[i - 1])
            self.b[i] = np.ones((self.layers[i], 1))

    def forward_propagation(self, X):
        values = {'A0': X.T}
        for i in range(1, self.n_layers):
            z = np.dot(self.w[i], values['A' + str(i-1)]) + self.b[i]
            if i == self.n_layers - 1:
                values['A' + str(i)] = z
            else:
                values['A' + str(i)] = sigmoid(z)
            values['Z' + str(i)] = z

        return values

    def compute_cost(self, values, y):
        m = y.shape[0]

        pred = values['A' + str(self.n_layers - 1)]
        pred = np.clip(pred, 1e-15, 1 - 1e-15)

        cost = - np.average(y.T * np.log(pred) + (1 - y.T) * np.log(1 - pred))

        L2_reg = (self.lmd / (2 * m)) * sum(np.sum(np.square(self.w[i])) for i in range(1, self.n_layers))

        return L2_reg + cost

    def compute_cost_derivative(self, values, y):
        return -(np.divide(y.T, values) - np.divide(1 - y.T, 1 - values)) / y.shape[0]

    def backward_propagation(self, values, y):
        m = y.shape[0]

        y = y.T

        grads = {}

        dA = self.compute_cost_derivative(values['A' + str(self.n_layers - 1)], y)

        for i in range(self.n_layers - 1, 0, -1):
            dZ = dA
            if i != self.n_layers - 1:
                dZ *= sigmoid_derivative(values['Z' + str(i)])

            grads['W' + str(i)] = (1 / m) * np.dot(dZ, values['A' + str(i-1)].T) + (self.lmd / m) * self.w[i]
            grads['B' + str(i)] = (1 / m) * np.sum(dZ, axis=1, keepdims=True)

            dA = np.dot(self.w[i].T, dZ)

        return grads

    def update_parameters(self, grads):
        for i in range(1, self.n_layers):
            self.w[i] -= self.alpha * grads['W' + str(i)]
            self.b[i] -= self.alpha * grads['B' + str(i)].reshape(self.b[i].shape)

    def fit(self, X_train, y_train, X_val=None, y_val=None):
        # initialize the parameters
        self.init_parameters()
        for epoch in range(self.epochs):
            # compute the values using the forward propagation
            values = self.forward_propagation(X_train)
            # compute the cost function
            cost = self.compute_cost(values, y_train)
            # append the latest values of the cost function into the corresponding list
            self.loss.append(cost)
            # compute the gradients using the back propagation method
            grads = self.backward_propagation(values, y_train)
            # update the parameters using the appropriate method
            self.update_parameters(grads)

    def predict(self, X_test):
        # compute the values using the testing set
        values = self.forward_propagation(X_test)
        # return the predictions of the latest layer (activation values of the last layer)
        return values['A' + str(self.n_layers - 1)].T

    def compute_performance(self, X, y):
        y_pred = self.predict(X)
        metrics = ClassificationMetrics(y, y_pred)
        return metrics.compute_performance()

    def plot_loss(self):
        plt.plot(self.loss, label='Training Loss')
        if self.loss_val:
            plt.plot(self.loss_val, label='Validation Loss')
        plt.xlabel("Epochs")
        plt.ylabel("Loss")
        plt.title("Loss curve")
        plt.legend()
        plt.show()
