import numpy as np
import matplotlib.pyplot as plt
from regression_metrics import RegressionMetrics


# define the activation function (sigmoid)
def sigmoid(z):
    return 1 / (1 + np.exp(-z))


# define the derivative of the activation function
def sigmoid_derivative(z):
    return sigmoid(z) * (1 - sigmoid(z))


# create the NN class
class NeuralNetwork:
    def __init__(self, layers, epochs=700, alpha=1e-2, lmd=1):
        # number of neurons for each layer
        self.layers = layers
        # number of layers
        self.n_layers = len(layers)
        # number of epochs for training step
        self.epochs = epochs
        # learning rate
        self.alpha = alpha
        # regularization factor
        self.lmd = lmd

        # weights dictionary
        self.w = {}
        # bias dictionary
        self.b = {}
        # loss function list
        self.loss = []
        # validation loss function list
        self.loss_val = []

    # method to initialize weights and biases
    def init_parameters(self):
        np.random.seed(42)
        for i in range(1, self.n_layers):
            # for each layer, initialize randomly the weights as a matrix
            # the matrix dimension depends on the number of neurons on the actual layer
            # and the number of neurons of the previous layer
            self.w[i] = np.random.randn(self.layers[i], self.layers[i - 1])
            # similarly, initialize a matrix fo dimension "number of neurons of the actual layer" x 1
            self.b[i] = np.ones((self.layers[i], 1))

    # method to forward propagate the initial inputs to all the subsequent neurons and layers
    def forward_propagation(self, X):
        # initialize with the transpose of the input vector
        values = {"A0": X.T}
        for i in range(1, self.n_layers):
            # calculate the weighted sum as a matrix product
            # between the weights matrix (between the layer i and the previous layer)
            # and the activation values of the previous layer
            # then add the biases
            z = np.dot(self.w[i], values["A" + str(i-1)]) + self.b[i]
            if i == self.n_layers - 1:
                # the output value has no activation function
                values["A" + str(i)] = z
            else:
                # the other layers need to be activated using the sigmoid applied to the weighted sum just calculated
                values["A" + str(i)] = sigmoid(z)
            # save the value of Z in the values' dictionary
            values["Z" + str(i)] = z
        # return the values
        return values

    # compute the cost using L2 regularization
    def compute_cost(self, values, y):
        # extract the number of samples
        m = y.shape[0]

        # compute the predictions as the activated values of the last layer
        pred = values["A" + str(self.n_layers - 1)]

        # compute the cost function as MSE
        cost = np.sum((pred - y.T) ** 2) / (2 * m)

        # compute the regularization term as the square of the sum of all the weights in the NN
        L2_reg = (self.lmd / (2 * m)) * sum(np.sum(np.square(self.w[i])) for i in range(1, self.n_layers))

        # return the entire function
        return cost + L2_reg

    # create the backpropagation method
    def back_propagation(self, values, X, y):
        # extract the number of samples
        m = y.shape[0]

        # transpose the output vector
        y = y.T

        # instantiate the gradients' dictionary
        grads = {}

        # compute the difference between the ground truth and the last activated values that represent the output
        dA = values["A" + str(self.n_layers - 1)] - y

        # for each layer excluded the input one (the 0th layer) go back of 1 layer (-1)
        for i in range(self.n_layers - 1, 0, -1):
            # dZ represents the gradient of the output w.r.t. a specific layer during backpropagation
            # since there is no further activation function after the output layer, dZ is set equal to dA
            dZ = dA
            if i != self.n_layers - 1:
                # compute the actual gradient multiplying it by the activation function of the actual layer
                dZ *= sigmoid_derivative(values["Z" + str(i)])
            # compute the derivative of the weights with the regularization term
            grads["W" + str(i)] = (1 / m) * np.dot(dZ, values["A" + str(i-1)].T) + (self.lmd / m) * self.w[i]
            # compute the derivative of the bias
            grads["B" + str(i)] = (1 / m) * np.sum(dZ, axis=1, keepdims=True)
            # compute dA for the previous layer
            dA = np.dot(self.w[i].T, dZ)

        return grads

    # update parameters method to update weights and biases using the gradients just calculated
    def update_parameters(self, grads):
        for i in range(1, self.n_layers):
            # update the weights using the gradient calculated before
            self.w[i] -= self.alpha * grads["W" + str(i)]
            # update the biases using the gradient calculated before
            self.b[i] -= self.alpha * grads["B" + str(i)].reshape(self.b[i].shape)

    # method to train the NN
    def fit(self, X_train, y_train, X_val=None, y_val=None):
        # initialize the parameters
        self.init_parameters()
        for epoch in range(self.epochs):
            # compute the values using the forward propagation
            values = self.forward_propagation(X_train)
            # compute the cost function
            cost = self.compute_cost(values, y_train)
            # append the latest values of the cost function into the corresponding list
            self.loss.append(cost)
            # compute the gradients using the back propagation method
            grads = self.back_propagation(values, X_train, y_train)
            # update the parameters using the appropriate method
            self.update_parameters(grads)

    def predict(self, X_test):
        # compute the values using the testing set
        values = self.forward_propagation(X_test)
        # return the predictions of the latest layer (activation values of the last layer)
        return values["A" + str(self.n_layers - 1)].T

    def compute_performance(self, X, y):
        y_pred = self.predict(X)
        metrics = RegressionMetrics(y, y_pred)
        return metrics.compute_performance()

    def plot_loss(self):
        plt.plot(self.loss, label='Training Loss')
        if self.loss_val:
            plt.plot(self.loss_val, label='Validation Loss')
        plt.xlabel("Epochs")
        plt.ylabel("Loss")
        plt.title("Loss curve")
        plt.legend()
        plt.show()