import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from classification_metrics import ClassificationMetrics
from classification_nn import NeuralNetwork

diabetes = pd.read_csv('datasets/diabetes.csv')
X = diabetes.drop(columns='Outcome').values
y = diabetes.Outcome.values

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

layers = [X.shape[1], 12, 1]  # Input layer, hidden layer, output layer
nn = NeuralNetwork(layers, epochs=1000, alpha=0.01, lmd=0.01)

nn.fit(X_train, y_train)

y_pred = nn.predict(X_test)
y_pred_class = np.where(y_pred > 0.5, 1, 0)

metrics = ClassificationMetrics(y_test, y_pred_class)
performance = metrics.compute_performance()
print("Performance on test data:")
for metric, value in performance.items():
    print(f"{metric}: {value}")

nn.plot_loss()