import numpy as np


class ClassificationMetrics:
    def __init__(self, y, pred):
        self.y = y
        self.pred = pred.reshape(-1)

        self.tp = np.sum((self.y == 1) & (self.pred == 1))
        self.tn = np.sum((self.y == 0) & (self.pred == 0))

        self.fp = np.sum((self.y == 0) & (self.pred == 1))
        self.fn = np.sum((self.y == 1) & (self.pred == 0))

    def compute_performance(self):
        return {
            "confusion_matrix": self.confusion_matrix(),
            "accuracy": self.accuracy(),
            "error_rate": self.error_rate(),
            "precision": self.precision(),
            "recall": self.recall(),
            "fn_rate": self.fn_rate(),
            "specificity": self.specificity(),
            "fp_rate": self.fp_rate(),
            "f1_score": self.f1_score()
        }

    def confusion_matrix(self):
        return np.array([[self.tn, self.fp], [self.fn, self.tp]])

    def accuracy(self):
        return (self.tp + self.tn) / len(self.y)

    def error_rate(self):
        return 1 - self.accuracy()

    def precision(self):
        return self.tp / (self.tp + self.fp)

    def recall(self):
        return self.tp / (self.tp + self.fn)

    def fn_rate(self):
        return 1 - self.recall()

    def specificity(self):
        return self.tn / (self.tn + self.fp)

    def fp_rate(self):
        return 1 - self.specificity()

    def f1_score(self):
        return 2 * (self.precision() * self.recall()) / (self.precision() + self.recall())