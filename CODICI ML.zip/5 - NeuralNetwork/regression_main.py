import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from regression_nn import NeuralNetwork

houses = pd.read_csv('datasets/houses_portaland_simple.csv')

X = houses[['Size', 'Bedroom']].values
y = houses.Price.values.reshape(-1, 1)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

layers = [2, 10, 1]

scaler_x = StandardScaler()
X_train = scaler_x.fit_transform(X_train)
X_test = scaler_x.transform(X_test)

scaler_y = StandardScaler()
y_train = scaler_y.fit_transform(y_train)
y_test = scaler_y.transform(y_test)

nn = NeuralNetwork(layers, epochs=1000, alpha=0.001, lmd=0.001)

nn.fit(X_train, y_train, X_val=X_test, y_val=y_test)

nn.plot_loss()

performance = nn.compute_performance(X_test, y_test)
print("Performance on test set:")
print(performance)