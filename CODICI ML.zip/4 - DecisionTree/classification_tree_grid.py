import pandas as pd
from matplotlib import pyplot as plt
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.tree import DecisionTreeClassifier, plot_tree

# import the dataset
diabetes = pd.read_csv('datasets/diabetes.csv')

# extract the features and set the output
X = diabetes.drop(columns='Outcome').values
y = diabetes.Outcome.values

# shuffle and split the dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# create the parameters' grid
param_grid = {
    'criterion': ['gini', 'entropy'],
    'min_samples_leaf': list(range(5, 20)),
    'max_depth': list(range(5, 20)),
}

# instantiate the grid
grid_search = GridSearchCV(DecisionTreeClassifier(random_state=42), param_grid=param_grid, cv=5, scoring='accuracy', verbose=True)

# train the model
grid_search.fit(X_train, y_train)

# obtain the best parameters
best_params = grid_search.best_params_

# obtain the best model
best_model = grid_search.best_estimator_

# use the best model to make predictions
y_pred = best_model.predict(X_test)

# compute the metrics
accuracy = accuracy_score(y_test, y_pred)
confusion_matrix = confusion_matrix(y_test, y_pred)

# print the parameters and metrics
print('Optimal Hyperparameters: ', best_params)
print(f'Accuracy: {accuracy:.2f}')
print(f'Confusion Matrix:\n{confusion_matrix}')

# plot the decision tree
plt.figure(figsize=(12, 8))
plot_tree(best_model, feature_names=diabetes.columns, filled=True)
plt.savefig(f'images/decision_tree_grid.png', format='png', bbox_inches="tight", dpi=600)