import pandas as pd
from matplotlib import pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.tree import plot_tree

diabetes = pd.read_csv('datasets/diabetes.csv')

X = diabetes.drop(columns='Outcome').values
y = diabetes.Outcome.values

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

criterion = 'entropy'
max_depth = 6
min_samples_leaf = 2

classifier = RandomForestClassifier(criterion=criterion, max_depth=max_depth, min_samples_leaf=min_samples_leaf,
                                    random_state=42)

classifier.fit(X_train, y_train)

y_pred = classifier.predict(X_test)

accuracy = accuracy_score(y_test, y_pred)
confusion_matrix = confusion_matrix(y_test, y_pred)

print(f'Accuracy: {accuracy}')
print(f'Confusion Matrix:\n{confusion_matrix}')

y_pred_train = classifier.predict(X_train)
accuracy = accuracy_score(y_train, y_pred_train)

print(f'Accuracy (training): {accuracy}')

for i in range(len(classifier)):
    plt.figure(figsize=(12, 8))
    plot_tree(classifier[i], feature_names=diabetes.columns, filled=True)
    plt.savefig(f'images/random_forest/decision_tree_{i}.png', format='png', bbox_inches="tight", dpi=600)
