import os

import pandas as pd
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree
import matplotlib.pyplot as plt

diabetes = pd.read_csv('datasets/diabetes.csv')

# extract all features as inputs and set the output
X = diabetes.drop(columns='Outcome').values
y = diabetes.Outcome.values

# shuffle and split the dataset into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=42, test_size=0.2)

# there is no need to normalize the dataset since the splitting depends on the variance
# we need to set the criterion to measure the quality of a feature w.r.t. the others
# we need to set the maximum number of branches (the depth)
# we need to set the minimum number of samples required to be a leaf node
criterion = 'entropy'
max_depth = 6
min_sample_leaf = 2

# instantiate the classifier
classifier = DecisionTreeClassifier(criterion=criterion, max_depth=max_depth, min_samples_leaf=min_sample_leaf,
                                    random_state=42)

# train the classifier
classifier.fit(X_train, y_train)

# predict the values
y_pred = classifier.predict(X_test)

# evaluate the metrics
accuracy = accuracy_score(y_test, y_pred)
conf_matrix = confusion_matrix(y_test, y_pred)

# print the metrics
print(f'Accuracy: {accuracy:.2f}')
print(f'Confusion Matrix:\n{conf_matrix}')

# evaluate the metrics on train set to address under/over fitting
y_pred_trained = classifier.predict(X_train)
accuracy_training = accuracy_score(y_train, y_pred_trained)
conf_matrix_training = confusion_matrix(y_train, y_pred_trained)

# print the metrics
print(f'Accuracy (training): {accuracy_training:.2f}')
print(f'Confusion Matrix (training):\n{conf_matrix_training}')

# plot the tree
plt.figure(figsize=(12, 8))
plot_tree(classifier, feature_names=diabetes.columns, filled=True)
plt.savefig(f'images/decision_tree.png', format='png', bbox_inches="tight", dpi=600)
