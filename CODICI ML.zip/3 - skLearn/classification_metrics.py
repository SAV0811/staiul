import numpy as np


class Evaluation:
    def __init__(self, y_true, y_pred):
        self.y_true = y_true
        self.y_pred = y_pred

        self.tp = np.sum((self.y_true == 1) & (self.y_pred == 1))
        self.fp = np.sum((self.y_true == 0) & (self.y_pred == 1))
        self.tn = np.sum((self.y_true == 0) & (self.y_pred == 0))
        self.fn = np.sum((self.y_true == 1) & (self.y_pred == 0))

    def accuracy(self):
        return (self.tp + self.tn) / (self.tp + self.tn + self.fp + self.fn)

    def precision(self):
        return (self.tp) / (self.tp + self.fp)

    def recall(self):
        return (self.tp) / (self.tp + self.fn)

    def f1_score(self):
        return 2 * self.recall() * self.precision() / (self.recall() + self.precision())

    def confusion_matrix(self):
        return [[self.tp, self.fp], [self.fn, self.tn]]