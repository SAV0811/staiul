import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# import the dataset into a pandas' dataframe
diabetes = pd.read_csv("datasets/diabetes.csv")

# pick some features as input and set the output
X = diabetes[['Pregnancies', 'Glucose', 'BloodPressure', 'SkinThickness', 'Insulin',
              'BMI', 'DiabetesPedigreeFunction', 'Age']].values
y = diabetes.Outcome.values

# with the method "train_test_split()" we can split the dataset into train and test sets and shuffle it
# there is no need to shuffle the dataset because the method provides a parameter to set the shuffling seed
# the method "sample(frac=1).reset_index(drop=True)" is unnecessary!
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# normalize the dataset using Z - score normalization
# this is done by using the StandardScaler() method of sklearn.preprocessing library
# 1. initialize the scaler
scaler = StandardScaler()
# 2. fit the scaler using X_train to compute mean and std and then normalize X_train (fit_transform() method)
X_train = scaler.fit_transform(X_train)
# 3. use the already computed statistical parameters to transform X_test as well (transform() method)
X_test = scaler.transform(X_test)

# create the regressor using sklearn.model_selection library
logistic = LogisticRegression(random_state=42)

# train the model
logistic.fit(X_train, y_train)

# compute the predictions on the test set
y_pred = logistic.predict(X_test)

# evaluate the performances from sklearn.metrics library
accuracy = accuracy_score(y_test, y_pred)
classification_report_str = classification_report(y_test, y_pred)
conf_matrix = confusion_matrix(y_test, y_pred)

# print the results
print(f'Accuracy: {accuracy:.2f}')
print('Classification Report:\n', classification_report_str)
print('Confusion Matrix:\n', conf_matrix)