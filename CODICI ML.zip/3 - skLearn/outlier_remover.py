import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin


class OutlierRemover(BaseEstimator, TransformerMixin):
    def __init__ (self, factor=1.5):
        self.factor = factor
        self.lower_bound = []
        self.upper_bound = []

    def outlier_detector(self, X):
        q1 = np.percentile(X, 25)
        q3 = np.percentile(X, 75)

        iqr = q3 - q1

        self.lower_bound.append(q1 - (self.factor * iqr))
        self.upper_bound.append(q3 + (self.factor * iqr))

    def fit(self, X, y=None):
        self.lower_bound = []
        self.upper_bound = []

        np.apply_along_axis(self.outlier_detector, axis=0, arr=X)

        return self

    def transform(self, X, y=None):
        for i in range(X.shape[1]):
            x = X[:, i]
            lower_mask = x < self.lower_bound[i]
            upper_mask = x > self.upper_bound[i]

            x[lower_mask | upper_mask] = np.nan

            X[:, i] = x

        return X