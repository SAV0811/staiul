import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from outlier_remover import OutlierRemover

# import the dataset into a dataframe
diabetes = pd.read_csv('datasets/diabetes.csv')

# extract features and set the ground truth
X = diabetes[['Pregnancies', 'Glucose', 'BloodPressure', 'SkinThickness', 'Insulin',
              'BMI', 'DiabetesPedigreeFunction', 'Age']].values
y = diabetes.Outcome.values

# shuffle and split the dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=42, test_size=0.2)

# create the numeric transformer (with no imputer because it has been implemented in the OutlierRemover() class!)
numeric_features = list(range(X.shape[1]))
numeric_transformer = Pipeline(steps=[('outlier_remover', OutlierRemover()), ('scaler', StandardScaler())])

# create the preprocessor
preprocessor = ColumnTransformer(transformers=[('num', numeric_transformer, numeric_features)], remainder='passthrough')

# instantiate the pipeline
pipeline = Pipeline(steps=[('preprocessor', preprocessor),
                           ('classifier', LogisticRegression(C=1, solver='liblinear', penalty='l1'))])

# train the pipeline
pipeline.fit(X_train, y_train)

# predict the values
y_pred = pipeline.predict(X_test)

# evaluate the metrics
accuracy = accuracy_score(y_test, y_pred)
report = classification_report(y_test, y_pred)
conf_matrix = confusion_matrix(y_test, y_pred)

# print the metrics
print(f'Accuracy: {accuracy:.2f}')
print('Classification Report:\n', report)
print('Confusion Matrix:\n', conf_matrix)

