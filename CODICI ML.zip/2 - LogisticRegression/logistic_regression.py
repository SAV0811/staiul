import numpy as np

np.random.seed(123)


class LogisticRegression:
    def __init__(self, learning_rate=1e-2, n_features=1, n_steps=2000):
        self.learning_rate = learning_rate
        self.n_features = n_features
        self.n_steps = n_steps
        self.theta = np.random.rand(self.n_features)

    def sigmoid(self, z):
        return 1 / (1 + np.exp(-z))

    def fit_full_batch(self, X, y):

        # m is the number of samples
        m = len(X)

        # initialize the theta_history and cost_history vectors
        cost_history = np.zeros(self.n_steps)
        theta_history = np.zeros((self.n_steps, self.theta.shape[0]))

        # full batch GD algorithm
        for step in range(0, self.n_steps):
            z = np.dot(X, self.theta)
            preds = self.sigmoid(z)
            error = preds - y
            self.theta -= self.learning_rate * (1 / m) * np.dot(X.T, error)
            theta_history[step, :] = self.theta.T

            cost = - (1 / m) * (np.dot(y, np.log(preds)) + np.dot(1 - y, np.log(1 - preds)))
            cost_history[step] = cost

        return cost_history, theta_history

    def predict(self, X):
        return self.sigmoid(np.dot(X, self.theta))

    def fit_mini_batch(self, X, y, batch_size=8):
        m = len(X)
        cost_history = np.zeros(self.n_steps)
        theta_history = np.zeros((self.n_steps, self.theta.shape[0]))

        # mini batch GD algorithm
        for step in range(0, self.n_steps):
            total_error = np.zeros(X.shape[1])
            for i in range(0, m, batch_size):
                x_i = X[i:i+batch_size]
                y_i = y[i:i+batch_size]
                z = np.dot(x_i, self.theta)
                preds = self.sigmoid(z)
                error = preds - y_i
                total_error += np.dot(x_i.T, error)

            self.theta = self.theta - self.learning_rate * (1 / batch_size) * total_error

            theta_history[step, :] = self.theta.T

            z = np.dot(X, self.theta)
            preds = self.sigmoid(z)
            cost = - (1 / m) * (np.dot(y, np.log(preds)) + np.dot(1 - y, np.log(1 - preds)))
            cost_history[step] = cost

        return cost_history, theta_history

    def fit_sgd(self, X, y):
        m = len(X)
        cost_history = np.zeros(self.n_steps)
        theta_history = np.zeros((self.n_steps, self.theta.shape[0]))

        # stochastic GD algorithm
        for step in range(0, self.n_steps):
            random_index = np.random.randint(m)
            x_i = X[random_index]
            y_i = y[random_index]
            z = np.dot(x_i, self.theta)
            preds = self.sigmoid(z)
            error = preds - y_i
            self.theta = self.theta - self.learning_rate * np.dot(x_i.T, error)

            theta_history[step, :] = self.theta.T
            z = np.dot(X, self.theta)
            preds = self.sigmoid(z)
            cost = - (1 / m) * (np.dot(y, np.log(preds)) + np.dot(1 - y, np.log(1 - preds)))
            cost_history[step] = cost

        return cost_history, theta_history
