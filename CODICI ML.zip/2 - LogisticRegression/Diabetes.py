import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from logistic_regression import LogisticRegression
from evaluation import Evaluation
import utilities

# import the dataset into a pandas' dataframe
diabetes = pd.read_csv('datasets/diabetes.csv')

# shuffle to remove grouping bias
diabetes = diabetes.sample(frac=1).reset_index(drop=True)

# pick only some features
X = diabetes[['Pregnancies', 'Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI',
              'DiabetesPedigreeFunction', 'Age']].values

# set the ground truth
y = diabetes.Outcome.values

# set the index to split into train and test
train_index = round(len(X) * 0.8)

# split the dataset into train and test sets
# train set
X_train = X[:train_index]
y_train = y[:train_index]

# test set
X_test = X[train_index:]
y_test = y[train_index:]

# compute mean and standard deviation to normalize the dataset
mean = X_train.mean(axis=0)
std = X_train.std(axis=0)

# normalize the dataset using Z - score normalization
X_train = (X_train - mean) / std
X_test = (X_test - mean) / std

# add the bias column
X_train = np.c_[np.ones(X_train.shape[0]), X_train]
X_test = np.c_[np.ones(X_test.shape[0]), X_test]

# create the regressor
logistic = LogisticRegression(n_steps=500, learning_rate=1e-1, n_features=X_train.shape[1])

# fit the model using full batch GD
cost_history, theta_history = logistic.fit_full_batch(X_train, y_train)

# compute the predictions on the test set
y_pred = logistic.predict(X_test)

# round the predictions' values to 1 if greater than 0.5, 0 otherwise
y_pred = np.where(y_pred > 0.5, 1, 0)

# compute and print the metrics
metrics = Evaluation(y_test, y_pred).compute_metrics(y_test, y_pred)
print("\n\nClassification Metrics Full batch:")
print("Confusion matrix: ", metrics["Confusion Matrix"])
print("Accuracy:", metrics["Accuracy"])
print("Precision:", metrics["Precision"])
print("Recall:", metrics["Recall"])
print("F1 Score:", metrics["F-1 Score"])

# plot the results
utilities.plot_theta_gd(X_train, y_train, logistic, cost_history, theta_history)
plt.figure(figsize=(12, 6))
for i in range(logistic.theta.shape[0]):
    plt.plot(range(logistic.n_steps), theta_history[:, i], label=f'fit_full_batch Theta {i + 1}')
plt.xlabel('Iteration')
plt.ylabel('Theta Value')
plt.legend()
plt.title('Change in Theta Values over Iterations in full_batch')
plt.grid(True)
plt.show()

# fit the model using full batch GD
cost_history, theta_history = logistic.fit_mini_batch(X_train, y_train, batch_size=32)

# compute the predictions on the test set
y_pred = logistic.predict(X_test)

# round the predictions' values to 1 if greater than 0.5, 0 otherwise
y_pred = np.where(y_pred > 0.5, 1, 0)

# compute and print the metrics
metrics = Evaluation(y_test, y_pred).compute_metrics(y_test, y_pred)
print("\n\nClassification Metrics Mini batch:")
print("Confusion matrix: ", metrics["Confusion Matrix"])
print("Accuracy:", metrics["Accuracy"])
print("Precision:", metrics["Precision"])
print("Recall:", metrics["Recall"])
print("F1 Score:", metrics["F-1 Score"])

# plot the results
utilities.plot_theta_gd(X_train, y_train, logistic, cost_history, theta_history)
plt.figure(figsize=(12, 6))
for i in range(logistic.theta.shape[0]):
    plt.plot(range(logistic.n_steps), theta_history[:, i], label=f'fit_mini_batch Theta {i + 1}')
plt.xlabel('Iteration')
plt.ylabel('Theta Value')
plt.legend()
plt.title('Change in Theta Values over Iterations in mini batch')
plt.grid(True)
plt.show()

# fit the model using full batch GD
cost_history, theta_history = logistic.fit_sgd(X_train, y_train)

# compute the predictions on the test set
y_pred = logistic.predict(X_test)

# round the predictions' values to 1 if greater than 0.5, 0 otherwise
y_pred = np.where(y_pred > 0.5, 1, 0)

# compute and print the metrics
metrics = Evaluation(y_test, y_pred).compute_metrics(y_test, y_pred)
print("\n\nClassification Metrics SGD:")
print("Confusion matrix: ", metrics["Confusion Matrix"])
print("Accuracy:", metrics["Accuracy"])
print("Precision:", metrics["Precision"])
print("Recall:", metrics["Recall"])
print("F1 Score:", metrics["F-1 Score"])

# plot the results
utilities.plot_theta_gd(X_train, y_train, logistic, cost_history, theta_history)
plt.figure(figsize=(12, 6))
for i in range(logistic.theta.shape[0]):
    plt.plot(range(logistic.n_steps), theta_history[:, i], label=f'fit_sgd Theta {i + 1}')
plt.xlabel('Iteration')
plt.ylabel('Theta Value')
plt.legend()
plt.title('Change in Theta Values over Iterations in SGD')
plt.grid(True)
plt.show()
