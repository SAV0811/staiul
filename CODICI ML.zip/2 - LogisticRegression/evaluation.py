import numpy as np


def confusion_matrix(y_test, y_pred):
    tp = np.sum((y_test == 1) & (y_pred == 1))
    tn = np.sum((y_test == 0) & (y_pred == 0))

    fp = np.sum((y_test == 0) & (y_pred == 1))
    fn = np.sum((y_test == 1) & (y_pred == 0))
    return np.array([[tn, fp], [fn, tp]])


class Evaluation:
    def __init__(self, y_test, y_pred):
        y_test_test = y_test
        y_test_pred = y_pred

    def accuracy(self, y_test, y_pred):
        return np.sum(y_test == y_pred) / len(y_test)

    def precision(self, y_test, y_pred):
        tp = np.sum((y_test == 1) & (y_pred == 1))
        fp = np.sum((y_test == 1) & (y_pred == 0))
        return tp / (tp + fp)

    def recall(self, y_test, y_pred):
        tp = np.sum((y_test == 1) & (y_pred == 1))
        fn = np.sum((y_test == 1) & (y_pred == 0))
        return tp / (tp + fn)

    def f1(self, y_test, y_pred):
        return 2 * ((self.precision(y_test, y_pred) * self.recall(y_test, y_pred)) / (self.precision(y_test, y_pred) +
                                                                                      self.recall(y_test, y_pred)))

