import numpy as np
from sklearn.metrics.pairwise import euclidean_distances


class KMedoids(object):
    def __init__(self, n_clusters=2, dist=euclidean_distances, random_state=42):
        self.n_clusters = n_clusters
        self.dist = dist
        self.random_state = np.random.RandomState(random_state)
        self.cluster_centers_ = []
        self.indices = []
        self.y_pred = None

    def fit(self, X):
        # instantiate the prng to generate integer numbers
        random_int = self.random_state.randint
        # initialize the first medoid
        self.indices = [random_int(X.shape[0])]
        # loop to generate the other medoids
        for _ in range(self.n_clusters - 1):
            # generate a new index
            i = random_int(X.shape[0])
            # check if the new index as been already generated: if so, generate a new one
            while i in self.indices:
                i = random_int(X.shape[0])
            # elsewhere, append the new index to the indices' list
            self.indices.append(i)
        # use the indices to instantiate new medoids
        self.cluster_centers_ = X[self.indices, :]

        # calculate the cost and the predicted outputs using the current medoids
        cost, self.y_pred = self.compute_cost(X, self.indices)

        # initialize variables to track the best configuration
        new_cost = cost
        new_y_pred = self.y_pred.copy()
        new_indices = self.indices[:]

        # boolean condition to iterate and compute new medoids with better costs
        initial = True

        while (new_cost < cost) | initial:
            initial = False
            cost = new_cost
            self.y_pred = new_y_pred
            self.indices = new_indices

            for k in range(self.n_clusters):
                k_cluster_indices = [i for i, x in enumerate(new_y_pred == k) if x]

                for r in k_cluster_indices:
                    if r not in self.indices:
                        indices_temp = self.indices[:]
                        indices_temp[k] = r
                        new_cost_temp, y_pred_temp = self.compute_cost(X, indices_temp)
                        if new_cost_temp < new_cost:
                            new_cost = new_cost_temp
                            new_y_pred = y_pred_temp
                            new_indices = indices_temp[:]

        self.cluster_centers_ = X[self.indices, :]

    def compute_cost(self, X, indices):
        y_pred = np.argmin(self.dist(X, X[indices, :]), axis=1)
        total_cost = np.sum([np.sum(self.dist(X[y_pred == 1], X[[indices[i]], :])) for i in set(y_pred)])

        return total_cost, y_pred

    def predict(self, X):
        return np.argmin(self.dist(X, self.cluster_centers_), axis=1)
