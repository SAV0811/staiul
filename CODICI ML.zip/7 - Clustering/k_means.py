import numpy as np
from sklearn.metrics.pairwise import euclidean_distances


class KMeans(object):
    def __init__(self, n_clusters=2, dist=euclidean_distances, random_state=42):
        self.n_clusters = n_clusters
        self.dist = dist
        self.random_state = np.random.RandomState(random_state)
        # a list that contains the centres of the clusters
        self.cluster_centers_ = []
        # a list to contain the predicted output values
        self.y_pred = None

    def fit(self, X):
        # create a prng to generate integer
        random_int = self.random_state.randint
        # initialize the first centroid index
        initial_indices = [random_int(X.shape[0])]
        # generate the other centroids
        for _ in range(self.n_clusters - 1):
            # generate a random integer between 0 and the dimension of X (excluded)
            i = random_int(X.shape[0])
            # check if this new index has been already generated
            # if so, generate a new one
            while i in initial_indices:
                i = random_int(X.shape[0])
            # if the new index has not been generated before, append it to the list of initial_indices
            initial_indices.append(i)
        # initialize the centroid's centres
        self.cluster_centers_ = X[initial_indices, :]
        # create a loop for centres update
        continue_condition = True
        while continue_condition:
            # copy the old centroids with the new ones for comparison
            old_centroids = self.cluster_centers_.copy()

            # predict the outputs
            self.y_pred = self.predict(X)

            # update the centroids as the mean of the points in the clusters
            for i in set(self.y_pred):
                self.cluster_centers_[i] = np.mean(X[self.y_pred == i], axis=0)

            # check for convergence
            if np.array_equal(old_centroids, self.cluster_centers_):
                continue_condition = False

    def predict(self, X):
        # for each row, returns the index of the nearest centroid
        # the neighbouring is measured using the Euclidean distance defined in the __init__ method
        # elsewhere, the distance metric is passed as a parameter
        return np.argmin(self.dist(X, self.cluster_centers_), axis=1)
